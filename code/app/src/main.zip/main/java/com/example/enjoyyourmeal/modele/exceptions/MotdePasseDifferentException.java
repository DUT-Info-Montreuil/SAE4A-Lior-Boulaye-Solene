package com.example.enjoyyourmeal.modele.exceptions;

public class MotdePasseDifferentException extends Exception {
}
