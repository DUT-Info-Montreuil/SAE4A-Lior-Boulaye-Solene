package com.example.enjoyyourmeal.modele.exceptions;

public class ChampsNonRempliExecption extends Exception {
}
