package com.example.enjoyyourmeal.modele.exceptions;

public class pseudoDejaExistantException extends Exception {
}
