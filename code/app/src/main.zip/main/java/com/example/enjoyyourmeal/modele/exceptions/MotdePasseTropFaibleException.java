package com.example.enjoyyourmeal.modele.exceptions;

public class MotdePasseTropFaibleException extends Exception {
}
