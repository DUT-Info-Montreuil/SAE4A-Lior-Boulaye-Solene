package com.example.enjoyyourmeal.modele;

public class Utilsateur {
    private String pseudo;

}
